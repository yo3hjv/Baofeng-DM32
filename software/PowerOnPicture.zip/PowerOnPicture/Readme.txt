Boot Image Download Guide

    Run the "Boot Image Download" tool.

    Select the communication type: COM.

    Choose the display type: "Color Screen".

    Set the image width:

        For DM32 (2-inch screen): 240×320.

        Set Width: 240.

        Set Height: 320.

    Open the image file (.BMP or .JPG format).

    Turn on the walkie-talkie and click "Download Image".

Additional Options:

    Click "Save BIN" to save the image as a .BIN file for future direct import.

    Click "Open BIN" to load a previously saved .BIN image file. Then, turn on the radio and click "Download Image".

=================================================

开机图片下载指南
运行“开机图片下载”工具
选择通讯类型：COM
显示屏类型“彩屏”
设置图片宽度：DM32为2”240*320.
设置宽度：240
设置高度：320
打开图片（.bmp或.JPG格式）
打开对讲机，点击“下载图片”。

或点击“保存bin”，将图片保存为.bin文件，以便下次直接导入。
或点击“打开bin”，打开早前保存的bin文件图片，打开对讲机，点击“下载图片”

